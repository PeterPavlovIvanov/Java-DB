package com.softuni.demo.services.impl;

import com.softuni.demo.dtos.fifthEx.CustomerDto;
import com.softuni.demo.dtos.sixthExercise.CarSixthDto;
import com.softuni.demo.dtos.sixthExercise.ResultDto;
import com.softuni.demo.entities.Car;
import com.softuni.demo.entities.Customer;
import com.softuni.demo.entities.Part;
import com.softuni.demo.entities.Sale;
import com.softuni.demo.repositories.SaleRepository;
import com.softuni.demo.services.CarService;
import com.softuni.demo.services.CustomerService;
import com.softuni.demo.services.SaleService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
public class SaleServiceImpl implements SaleService {

    private final SaleRepository saleRepository;
    private final CarService carService;
    private final CustomerService customerService;
    private final ModelMapper modelMapper;

    public SaleServiceImpl(SaleRepository saleRepository, CarService carService, CustomerService customerService, ModelMapper modelMapper) {
        this.saleRepository = saleRepository;
        this.carService = carService;
        this.customerService = customerService;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedSales() {
        if (this.saleRepository.count() != 0) {
            return;
        }

        for (Car car : this.carService.getAll()) {
            Customer customer = this.customerService.getById(new Random().nextInt(this.customerService.getAll().size()) + 1);
            Sale sale = new Sale();
            sale.setCar(car);
            sale.setCustomer(customer);

            int[] discounts = {0, 5, 10, 15, 20, 30, 40, 50};
            int randomDiscount = new Random().nextInt(discounts.length);
            sale.setDiscount(discounts[randomDiscount]);
            if (customer.isYoungDriver()) {
                sale.setDiscount(sale.getDiscount() + 5);
            }

            this.saleRepository.saveAndFlush(sale);
        }
        System.out.println("Sales seeded successfully.");
    }

    @Override
    public List<Sale> getAllByCustomer(Customer customer) {
        return this.saleRepository.findAllByCustomer(customer);
    }

    @Override
    public List<ResultDto> getExerciseSix() {
        List<Sale> sales = this.saleRepository.findAll();
        List<ResultDto> resultList = new ArrayList<>();

        for (Sale sale : sales) {
            CarSixthDto carSixthDto = this.modelMapper.map(sale.getCar(), CarSixthDto.class);

            String customerName = sale.getCustomer().getName();
            int discount = sale.getDiscount();
            double realDiscount = 1 - ((double) discount / 100);
            BigDecimal price = new BigDecimal(0);
            for (Part part : sale.getCar().getParts()) {
                price = price.add(part.getPrice());
            }
            BigDecimal priceWithDiscount = price.multiply(new BigDecimal(realDiscount));

            ResultDto resultDto = new ResultDto(carSixthDto, customerName, discount, price, priceWithDiscount);
            resultList.add(resultDto);
        }

        return resultList;
    }

    @Override
    public List<CustomerDto> getExerciseFive() {
        List<Customer> customers = this.customerService.getAll();
        List<CustomerDto> result = new ArrayList<>();

        for (Customer customer : customers) {
            String name = customer.getName();
            int boughtCars = 0;
            BigDecimal spentMoney = new BigDecimal(0);

            List<Sale> allByCustomer = this.saleRepository.findAllByCustomer(customer);
            for (Sale sale : allByCustomer) {
                for (Part part : sale.getCar().getParts()) {
                    spentMoney = spentMoney.add(part.getPrice());
                }
                boughtCars++;
            }

            CustomerDto customerDto = new CustomerDto(name, boughtCars, spentMoney);
            result.add(customerDto);
        }

        result = result.stream().filter(customerDto -> customerDto.getBoughtCars() > 0).collect(Collectors.toList());
        result.sort((a, b) -> new BigDecimal(b.getBoughtCars()).compareTo(new BigDecimal(a.getBoughtCars())));
        result.sort((a, b) -> b.getSpentMoney().compareTo(a.getSpentMoney()));

        return result;
    }
}
