package com.softuni.demo.services.impl;

import com.softuni.demo.dtos.CustomerSeedDto;
import com.softuni.demo.dtos.firstEx.CustomerFirstExDto;
import com.softuni.demo.entities.Customer;
import com.softuni.demo.entities.Sale;
import com.softuni.demo.repositories.CustomerRepository;
import com.softuni.demo.repositories.SaleRepository;
import com.softuni.demo.services.CustomerService;
import com.softuni.demo.utils.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final ModelMapper modelMapper;
    private final SaleRepository saleRepository;

    public CustomerServiceImpl(CustomerRepository customerRepository, ModelMapper modelMapper, SaleRepository saleRepository) {
        this.customerRepository = customerRepository;
        this.modelMapper = modelMapper;
        this.saleRepository = saleRepository;
    }


    @Override
    public void seedCustomers(CustomerSeedDto[] customerSeedDtos) {
        if (this.customerRepository.count() != 0) {
            return;
        }
        int count = 1;
        for (CustomerSeedDto customerSeedDto : customerSeedDtos) {
            Customer customer = new Customer();
            customer.setName(customerSeedDto.getName());
            customer.setDateOfBirth(customerSeedDto.getBirthDate());
            customer.setYoungDriver(customerSeedDto.isYoungDriver());
            customer.setId(count);
            count++;

            this.customerRepository.saveAndFlush(customer);
        }
        System.out.println("Customers seeded successfully.");
    }

    @Override
    public Customer getById(long id) {
        return this.customerRepository.findById(id);
    }

    @Override
    public List<Customer> getAll() {
        return this.customerRepository.findAll();
    }

    @Override
    public List<CustomerFirstExDto> getFirstExercise() {
        List<Customer> customers = this.customerRepository.findAllOrderByDateOfBirth();
        List<CustomerFirstExDto> customerFirstExDtoList = new ArrayList<>();

        for (Customer customer : customers) {
            CustomerFirstExDto customerFirstExDto = this.modelMapper.map(customer, CustomerFirstExDto.class);

            customerFirstExDto.setBirthDate(customer.getDateOfBirth());

            customerFirstExDto.setSales(this.saleRepository.findAllByCustomer(customer));

            customerFirstExDtoList.add(customerFirstExDto);
        }
        return customerFirstExDtoList;
    }

    @Override
    public List<Customer> getExerciseFive() {

        return null;
    }
}
