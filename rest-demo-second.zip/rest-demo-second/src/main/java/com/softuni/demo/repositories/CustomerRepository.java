package com.softuni.demo.repositories;

import com.softuni.demo.entities.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Customer findById(long id);
    List<Customer> findAll();
    @Query("SELECT c FROM Customer AS c ORDER BY c.dateOfBirth ASC")
    List<Customer> findAllOrderByDateOfBirth();

}
