package com.softuni.demo.services;

import com.softuni.demo.dtos.CustomerSeedDto;
import com.softuni.demo.dtos.firstEx.CustomerFirstExDto;
import com.softuni.demo.entities.Customer;

import java.util.List;

public interface CustomerService {
    void seedCustomers(CustomerSeedDto[] customerSeedDtos);
    Customer getById(long id);
    List<Customer> getAll();
    List<CustomerFirstExDto> getFirstExercise();

    List<Customer> getExerciseFive();
}
