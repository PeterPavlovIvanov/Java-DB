package com.softuni.demo.services;

import com.softuni.demo.dtos.CarSeedDto;
import com.softuni.demo.entities.Car;

import java.util.List;

public interface CarService {
    void seedCars(CarSeedDto[] carSeedDtos);
    Car getById(long id);
    List<Car> getAll();
    List<Car> findAllByMake(String make);
}
