package com.softuni.demo.services;

import com.softuni.demo.dtos.fifthEx.CustomerDto;
import com.softuni.demo.dtos.sixthExercise.ResultDto;
import com.softuni.demo.entities.Customer;
import com.softuni.demo.entities.Sale;

import java.util.List;

public interface SaleService {
    void seedSales();
    List<Sale> getAllByCustomer(Customer customer);
    List<ResultDto> getExerciseSix();
    List<CustomerDto> getExerciseFive();
}
