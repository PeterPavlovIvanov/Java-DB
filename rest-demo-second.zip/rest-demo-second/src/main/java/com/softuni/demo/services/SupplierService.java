package com.softuni.demo.services;

import com.softuni.demo.entities.Supplier;

import java.util.List;

public interface SupplierService {
    void seedSuppliers(Supplier[] suppliers);
    Supplier getById(long id);
    List<Supplier> getAll();
    List<Supplier> getThirdExercise();
}
