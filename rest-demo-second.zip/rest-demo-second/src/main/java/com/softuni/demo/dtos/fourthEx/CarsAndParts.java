package com.softuni.demo.dtos.fourthEx;

import com.google.gson.annotations.Expose;

import java.util.List;

public class CarsAndParts {
    @Expose
    private CarFourthDto car;
    @Expose
    private List<PartFourthDto> parts;

    public CarsAndParts() {
    }

    public CarsAndParts(CarFourthDto car, List<PartFourthDto> parts) {
        this.car = car;
        this.parts = parts;
    }

    public CarFourthDto getCar() {
        return car;
    }

    public void setCar(CarFourthDto car) {
        this.car = car;
    }

    public List<PartFourthDto> getParts() {
        return parts;
    }

    public void setParts(List<PartFourthDto> parts) {
        this.parts = parts;
    }
}
