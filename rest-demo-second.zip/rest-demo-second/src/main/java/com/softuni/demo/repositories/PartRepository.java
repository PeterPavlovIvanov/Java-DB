package com.softuni.demo.repositories;

import com.softuni.demo.entities.Car;
import com.softuni.demo.entities.Part;
import com.softuni.demo.entities.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PartRepository extends JpaRepository<Part,Long> {
    Part findById(long id);
    List<Part> findAll();
    List<Part> findAllBySupplier(Supplier supplier);
}
