package com.softuni.demo.dtos.thirdEx;

import com.google.gson.annotations.Expose;

public class SupplierThirdDto {
    @Expose
    private long id;
    @Expose
    private String name;
    @Expose
    private int partsCount;

    public SupplierThirdDto() {
    }

    public SupplierThirdDto(long id, String name, int partsCount) {
        this.id = id;
        this.name = name;
        this.partsCount = partsCount;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPartsCount() {
        return partsCount;
    }

    public void setPartsCount(int partsCount) {
        this.partsCount = partsCount;
    }
}
