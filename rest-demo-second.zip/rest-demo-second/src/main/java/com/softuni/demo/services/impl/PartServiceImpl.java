package com.softuni.demo.services.impl;

import com.softuni.demo.dtos.PartSeedDto;
import com.softuni.demo.entities.Part;
import com.softuni.demo.entities.Supplier;
import com.softuni.demo.repositories.PartRepository;
import com.softuni.demo.services.PartService;
import com.softuni.demo.services.SupplierService;
import com.softuni.demo.utils.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class PartServiceImpl implements PartService {

    private final PartRepository partRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final SupplierService supplierService;

    public PartServiceImpl(PartRepository partRepository, ModelMapper modelMapper, ValidationUtil validationUtil, SupplierService supplierService) {
        this.partRepository = partRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.supplierService = supplierService;
    }


    @Override
    public void seedParts(PartSeedDto[] partSeedDtos) {
        if (this.partRepository.count() != 0) {
            return;
        }
        for (PartSeedDto partSeedDto : partSeedDtos) {
            Part part = this.modelMapper.map(partSeedDto, Part.class);

            part.setSupplier(this.supplierService.getById(new Random()
                            .nextInt(this.supplierService.getAll().size()) + 1));

            this.partRepository.saveAndFlush(part);
        }
        System.out.println("Parts seeded successfully.");
    }

    @Override
    public Part getById(long id) {
        return this.partRepository.findById(id);
    }

    @Override
    public List<Part> getAll() {
        return this.partRepository.findAll();
    }

    @Override
    public List<Part> findAllBySupplier(Supplier supplier) {
        return this.partRepository.findAllBySupplier(supplier);
    }
}
