package com.softuni.demo.services.impl;

import com.softuni.demo.entities.Supplier;
import com.softuni.demo.repositories.SupplierRepository;
import com.softuni.demo.services.SupplierService;
import com.softuni.demo.utils.ValidationUtil;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import java.util.List;

@Service
public class SupplierServiceImpl implements SupplierService {

    private final SupplierRepository supplierRepository;
    private final ValidationUtil validationUtil;

    public SupplierServiceImpl(SupplierRepository supplierRepository, ValidationUtil validationUtil) {
        this.supplierRepository = supplierRepository;
        this.validationUtil = validationUtil;
    }

    @Override
    public void seedSuppliers(Supplier[] suppliers) {
        if(this.supplierRepository.count() != 0){
            return;
        }
        for(Supplier supplier : suppliers){
            if(this.validationUtil.isValid(supplier)){
                this.supplierRepository.saveAndFlush(supplier);
            }else{
                this.validationUtil.violations(supplier)
                        .stream()
                        .map(ConstraintViolation::getMessage)
                        .forEach(System.out::println);
            }
        }
        System.out.println("Suppliers seeded successfully.");
    }

    @Override
    public Supplier getById(long id) {
        return this.supplierRepository.findById(id);
    }

    @Override
    public List<Supplier> getAll() {
        return this.supplierRepository.findAll();
    }

    @Override
    public List<Supplier> getThirdExercise() {
        return this.supplierRepository.findAllByImporterFalse();
    }
}
