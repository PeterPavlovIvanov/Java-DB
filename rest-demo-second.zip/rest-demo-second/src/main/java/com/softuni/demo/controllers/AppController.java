package com.softuni.demo.controllers;

import com.google.gson.Gson;
import com.softuni.demo.dtos.CarSeedDto;
import com.softuni.demo.dtos.CustomerSeedDto;
import com.softuni.demo.dtos.PartSeedDto;
import com.softuni.demo.dtos.fourthEx.CarFourthDto;
import com.softuni.demo.dtos.fourthEx.CarsAndParts;
import com.softuni.demo.dtos.fourthEx.PartFourthDto;
import com.softuni.demo.dtos.secondEx.CarSecondDto;
import com.softuni.demo.dtos.thirdEx.SupplierThirdDto;
import com.softuni.demo.entities.Car;
import com.softuni.demo.entities.Part;
import com.softuni.demo.entities.Supplier;
import com.softuni.demo.services.*;
import com.softuni.demo.services.impl.CustomerServiceImpl;
import com.softuni.demo.utils.FileIOUtil;
import org.modelmapper.ModelMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class AppController implements CommandLineRunner {

    private final Gson gson;
    private final SupplierService supplierService;
    private final PartService partService;
    private final CarService carService;
    private final CustomerServiceImpl customerServiceImpl;
    private final SaleService saleService;
    private final FileIOUtil fileIOUtil;
    private final ModelMapper modelMapper;

    public AppController(Gson gson, SupplierService supplierService, PartService partService,
                         CarService carService, CustomerServiceImpl customerServiceimpl, SaleService saleService, FileIOUtil fileIOUtil, ModelMapper modelMapper) {
        this.gson = gson;
        this.supplierService = supplierService;
        this.partService = partService;
        this.carService = carService;
        this.customerServiceImpl = customerServiceimpl;
        this.saleService = saleService;
        this.fileIOUtil = fileIOUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public void run(String... args) throws Exception {
        //5. Car Dealer Import Data
        this.seedSuppliers();
        this.seedParts();
        this.seedCars();
        this.seedCustomers();
        this.seedSales();

        //6. Car Dealer Query and Export Data

//        this.exercise1();//Query 1 – Ordered Customers
//
//        this.exercise2();//Query 2 – Cars from Make Toyota
//
//        this.exercise3();//Query 3 – Local Suppliers
//
//        this.exercise4();//Query 4 – Cars with Their List of Parts
//
//        this.exercise5();//Query 5 – Total Sales by Customer
//
//        this.exercise6();//Query 6 – Sales with Applied Discount

        System.exit(0);
    }


    private void exercise1() throws IOException {
        System.out.println(this.gson.toJson(this.customerServiceImpl.getFirstExercise()));
        this.fileIOUtil.write(this.gson.toJson(this.customerServiceImpl.getFirstExercise()),
                "src/main/resources/outputs/output1.json");
    }

    private void exercise2() throws IOException {
        List<Car> toyotas = this.carService.findAllByMake("Toyota");
        List<CarSecondDto> carSecondDtos = new ArrayList<>();

        for (Car car : toyotas) {
            CarSecondDto carSecondDto = this.modelMapper.map(car, CarSecondDto.class);
            carSecondDtos.add(carSecondDto);
        }

        System.out.println(this.gson.toJson(carSecondDtos));
        this.fileIOUtil.write(this.gson.toJson(carSecondDtos),
                "src/main/resources/outputs/output2.json");
    }

    private void exercise3() throws IOException {
        List<Supplier> suppliers = this.supplierService.getThirdExercise();
        List<SupplierThirdDto> supplierThirdDtoList = new ArrayList<>();

        for (Supplier supplier : suppliers) {
            SupplierThirdDto supplierThirdDto =
                    new SupplierThirdDto(
                            supplier.getId(),
                            supplier.getName(),
                            this.partService.findAllBySupplier(supplier).size()
                    );

            supplierThirdDtoList.add(supplierThirdDto);
        }

        System.out.println(this.gson.toJson(supplierThirdDtoList));
        this.fileIOUtil.write(this.gson.toJson(supplierThirdDtoList), "src/main/resources/outputs/output3.json");
    }

    private void exercise4() throws IOException {
        List<Car> allCars = this.carService.getAll();
        List<CarsAndParts> carsAndPartsList = new ArrayList<>();

        for (Car car : allCars) {
            List<PartFourthDto> partFourthDtoList = new ArrayList<>();

            for (Part part : car.getParts()) {
                PartFourthDto partFourthDto = this.modelMapper.map(part, PartFourthDto.class);
                partFourthDtoList.add(partFourthDto);
            }

            CarFourthDto carFourthDto = this.modelMapper.map(car, CarFourthDto.class);
            CarsAndParts carsAndParts = new CarsAndParts(carFourthDto, partFourthDtoList);

            carsAndPartsList.add(carsAndParts);
        }

        System.out.println(this.gson.toJson(carsAndPartsList));
        this.fileIOUtil.write(this.gson.toJson(carsAndPartsList), "src/main/resources/outputs/output4.json");
    }

    private void exercise5() throws IOException {
        System.out.println(this.gson.toJson(this.saleService.getExerciseFive()));
        this.fileIOUtil.write(this.gson.toJson(this.saleService.getExerciseFive()),"src/main/resources/outputs/output5.json");
    }

    private void exercise6() throws IOException {
        System.out.println(this.gson.toJson(this.saleService.getExerciseSix()));
        this.fileIOUtil.write(this.gson.toJson(this.saleService.getExerciseSix()),"src/main/resources/outputs/output6.json");

    }

    private void seedSuppliers() throws FileNotFoundException {
        Supplier[] suppliers = this.gson
                .fromJson(new FileReader("src/main/resources/files/suppliers.json"),
                        Supplier[].class);

        this.supplierService.seedSuppliers(suppliers);
    }

    private void seedParts() throws FileNotFoundException {
        PartSeedDto[] partSeedDtos = this.gson
                .fromJson(new FileReader("src/main/resources/files/parts.json"),
                        PartSeedDto[].class);

        this.partService.seedParts(partSeedDtos);
    }

    private void seedCars() throws FileNotFoundException {
        CarSeedDto[] carSeedDto = this.gson
                .fromJson(new FileReader("src/main/resources/files/cars.json"),
                        CarSeedDto[].class);

        this.carService.seedCars(carSeedDto);
    }

    private void seedCustomers() throws FileNotFoundException {
        CustomerSeedDto[] customerSeedDtos = this.gson
                .fromJson(new FileReader("src/main/resources/files/customers.json"),
                        CustomerSeedDto[].class);

        this.customerServiceImpl.seedCustomers(customerSeedDtos);
    }

    private void seedSales() {
        this.saleService.seedSales();
    }
}
