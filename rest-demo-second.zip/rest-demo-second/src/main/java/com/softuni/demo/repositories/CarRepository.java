package com.softuni.demo.repositories;

import com.softuni.demo.entities.Car;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CarRepository extends JpaRepository<Car,Long> {
    Car findById(long id);
    List<Car> findAll();
    List<Car> findAllByMakeOrderByModelAscTravelledDistanceDesc(String make);
}
