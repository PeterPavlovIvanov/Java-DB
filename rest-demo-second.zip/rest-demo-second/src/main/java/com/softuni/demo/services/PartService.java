package com.softuni.demo.services;

import com.softuni.demo.dtos.PartSeedDto;
import com.softuni.demo.entities.Part;
import com.softuni.demo.entities.Supplier;

import java.util.List;

public interface PartService {
    void seedParts(PartSeedDto[] partSeedDtos);
    Part getById(long id);
    List<Part> getAll();
    List<Part> findAllBySupplier(Supplier supplier);
}
