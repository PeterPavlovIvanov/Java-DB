package com.softuni.demo.dtos.firstEx;

import com.google.gson.annotations.Expose;
import com.softuni.demo.entities.Sale;

import java.util.Date;
import java.util.List;

public class CustomerFirstExDto {
    @Expose
    private long id;
    @Expose
    private String name;
    @Expose
    private Date birthDate;
    @Expose
    private boolean isYoungDriver;
    @Expose
    private List<Sale> sales;

    public CustomerFirstExDto() {
    }

    public CustomerFirstExDto(long id, String name, Date birthDate, boolean isYoungDriver, List<Sale> sales) {
        this.id = id;
        this.name = name;
        this.birthDate = birthDate;
        this.isYoungDriver = isYoungDriver;
        this.sales = sales;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public boolean isYoungDriver() {
        return isYoungDriver;
    }

    public void setYoungDriver(boolean youngDriver) {
        isYoungDriver = youngDriver;
    }

    public List<Sale> getSales() {
        return sales;
    }

    public void setSales(List<Sale> sales) {
        this.sales = sales;
    }
}
