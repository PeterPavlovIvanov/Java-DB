package com.softuni.demo.repositories;

import com.softuni.demo.entities.Customer;
import com.softuni.demo.entities.Sale;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SaleRepository extends JpaRepository<Sale, Long> {
    List<Sale> findAllByCustomer(Customer customer);
    List<Sale> findAll();
}
