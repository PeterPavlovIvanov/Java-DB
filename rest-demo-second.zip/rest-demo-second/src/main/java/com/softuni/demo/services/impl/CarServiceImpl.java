package com.softuni.demo.services.impl;

import com.softuni.demo.dtos.CarSeedDto;
import com.softuni.demo.entities.Car;
import com.softuni.demo.entities.Part;
import com.softuni.demo.repositories.CarRepository;
import com.softuni.demo.repositories.PartRepository;
import com.softuni.demo.services.CarService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Random;

@Service
public class CarServiceImpl implements CarService {

    private final CarRepository carRepository;
    private final ModelMapper modelMapper;
    private final PartRepository partRepository;

    public CarServiceImpl(CarRepository carRepository, ModelMapper modelMapper, PartRepository partRepository) {
        this.carRepository = carRepository;
        this.modelMapper = modelMapper;
        this.partRepository = partRepository;
    }

    @Override
    public void seedCars(CarSeedDto[] carSeedDtos) {
        if (this.carRepository.count() != 0) {
            return;
        }
        int count = 1;
        for (CarSeedDto carSeedDto : carSeedDtos) {
            Car car = this.modelMapper.map(carSeedDto, Car.class);

            car.setParts(new HashSet<>());
            for (int i = 10; i > 0; i--) {

                //TODO Ако искате да сийднете всички коли моля коментирайте или изтрийте следващите 3 реда. Може да отнеме до половин час в зависимост от компютъра ви.
                if (count > 75) {
                    break;
                }

                if (car.getParts() == null || car.getParts().isEmpty() || car.getParts().size() == 0) {
                    car.setParts(new HashSet<>());
                }

                int ranNum = new Random().nextInt(this.partRepository.findAll().size()) + 1;
                Part part = this.partRepository.findById(ranNum);

                car.getParts().add(part);
                if (part.getCars() == null || part.getCars().size() == 0 || part.getCars().isEmpty()) {
                    part.setCars(new HashSet<>());
                }
                part.getCars().add(car);
                this.carRepository.save(car);
                this.partRepository.save(part);
            }
            System.out.println("Seeded cars: " + count);
            count++;
            this.carRepository.saveAndFlush(car);
        }
        System.out.println("Cars seeded successfully.");
    }

    @Override
    public Car getById(long id) {
        return this.carRepository.findById(id);
    }

    @Override
    public List<Car> getAll() {
        return this.carRepository.findAll();
    }

    @Override
    public List<Car> findAllByMake(String make) {
        return this.carRepository.findAllByMakeOrderByModelAscTravelledDistanceDesc(make);
    }
}
