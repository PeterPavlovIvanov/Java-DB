package com.example.demo.controllers;


import com.example.demo.dtos.firstEx.ProductFirstExDto;
import com.example.demo.dtos.firstEx.ProductRootFirstExDto;
import com.example.demo.dtos.fourthEx.UserRootFourthExDto;
import com.example.demo.dtos.secondEx.UserRootSecondExDto;
import com.example.demo.dtos.seeds.*;
import com.example.demo.dtos.thirdEx.CategoryRootThirdExDto;
import com.example.demo.entities.Product;
import com.example.demo.services.CategoryService;
import com.example.demo.services.ProductService;
import com.example.demo.services.UserService;
import com.example.demo.utils.FileIOUtil;
import com.example.demo.utils.XmlParser;
import org.modelmapper.ModelMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBException;
import java.io.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Component
public class AppController implements CommandLineRunner {

    private final XmlParser xmlParser;
    private final CategoryService categoryService;
    private final UserService userService;
    private final ProductService productService;
    private final FileIOUtil fileIOUtil;
    private final ModelMapper modelMapper;

    public AppController(XmlParser xmlParser, CategoryService categoryService, UserService userService, ProductService productService, FileIOUtil fileIOUtil, ModelMapper modelMapper) {
        this.xmlParser = xmlParser;
        this.categoryService = categoryService;
        this.userService = userService;
        this.productService = productService;
        this.fileIOUtil = fileIOUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("0   -> seed data");
        System.out.println("1-4 -> queries 1-4");
        System.out.println("5   -> exit");
        int menu = Integer.parseInt(scanner.nextLine());
        while (true) {
            switch (menu) {
                case 0:
                    this.seedUsers();
                    this.seedCategories();
                    this.seedProducts();
                    break;
                case 1:
                    this.exercise1();//Query 1 – Products in Range
                    break;
                case 2:
                    this.exercise2();//Query 2 – Successfully Sold Products
                    break;
                case 3:
                    this.exercise3();//Query 3 – Categories by Products Count
                    break;
                case 4:
                    this.exercise4();//Query 4 – Users and Products
                    break;
                case 5:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Try again with [0-5]");
                    break;
            }
            System.out.println("0   -> seed data\r\n1-4 -> queries 1-4\r\n5   -> exit");
            menu = Integer.parseInt(scanner.nextLine());
        }
    }

    private void exercise1() throws IOException, JAXBException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter lower range: ");
        BigDecimal lower = BigDecimal.valueOf(Double.parseDouble(bufferedReader.readLine()));
        System.out.println("Enter higher range: ");
        BigDecimal higher = BigDecimal.valueOf(Double.parseDouble(bufferedReader.readLine()));

        List<Product> allBetween = this.productService.getAllBetween(lower, higher);

        List<ProductFirstExDto> result = new ArrayList<>();
        for (Product product : allBetween) {
            String seller = product.getSeller().getFirstName() + " " + product.getSeller().getLastName();
            ProductFirstExDto productFirstExDto = new ProductFirstExDto();
            productFirstExDto.setName(product.getName());
            productFirstExDto.setSeller(seller);
            productFirstExDto.setPrice(product.getPrice());
            result.add(productFirstExDto);
        }

        ProductRootFirstExDto productRootSeedDto = new ProductRootFirstExDto();
        productRootSeedDto.setProducts(result);
        this.xmlParser.marshalToFile("src/main/resources/outputs/output1.xml", productRootSeedDto);
    }

    private void exercise2() throws IOException, JAXBException {
        UserRootSecondExDto userRootSecondExDto = new UserRootSecondExDto();
        userRootSecondExDto.setUsers(this.userService.findAllSecondExercise());

        this.xmlParser.marshalToFile("src/main/resources/outputs/output2.xml", userRootSecondExDto);
    }

    private void exercise3() throws IOException, JAXBException {
        CategoryRootThirdExDto categoryRootThirdExDto = new CategoryRootThirdExDto();
        categoryRootThirdExDto.setCategories(this.categoryService.getAllCategoriesThirdEx());

        this.xmlParser.marshalToFile("src/main/resources/outputs/output3.xml", categoryRootThirdExDto);
    }

    private void exercise4() throws IOException, JAXBException {
        UserRootFourthExDto userRootFourthExDto = new UserRootFourthExDto();

        userRootFourthExDto.setUsers(this.userService.findAllWithSoldProductsFourthExercise());
        userRootFourthExDto.setCount(this.userService.findAllWithSoldProductsFourthExercise().size());

        this.xmlParser.marshalToFile("src/main/resources/outputs/output4.xml", userRootFourthExDto);
    }

    private void seedProducts() throws FileNotFoundException, JAXBException {
        ProductRootSeedDto productRootSeedDto = this.xmlParser
                .unmarshalFromFile("src/main/resources/files/products.xml", ProductRootSeedDto.class);

        this.productService.seedProducts(productRootSeedDto.getProducts());
    }

    private void seedUsers() throws IOException, JAXBException {
        UserRootSeedDto userRootSeedDto = this.xmlParser
                .unmarshalFromFile("src/main/resources/files/users.xml", UserRootSeedDto.class);

        this.userService.seedUsers(userRootSeedDto.getUsers());
    }

    private void seedCategories() throws FileNotFoundException, JAXBException {
        CategoryRootSeedDto categoryRootSeedDto = this.xmlParser
                .unmarshalFromFile("src/main/resources/files/categories.xml", CategoryRootSeedDto.class);

        this.categoryService.seedCategories(categoryRootSeedDto.getCategories());
    }
}
