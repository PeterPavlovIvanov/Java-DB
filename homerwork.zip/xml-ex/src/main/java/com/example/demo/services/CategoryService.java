package com.example.demo.services;



import com.example.demo.dtos.seeds.CategorySeedDto;
import com.example.demo.dtos.thirdEx.CategoryThirdExDto;
import com.example.demo.entities.Category;

import java.util.List;

public interface CategoryService {
    void seedCategories(List<CategorySeedDto> categorySeedDtos);

    Category getById(long id);

    List<CategoryThirdExDto> getAllCategoriesThirdEx();
}
