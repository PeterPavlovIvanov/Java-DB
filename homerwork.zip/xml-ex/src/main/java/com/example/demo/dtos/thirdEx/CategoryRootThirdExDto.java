package com.example.demo.dtos.thirdEx;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "categories")
@XmlAccessorType(XmlAccessType.FIELD)
public class CategoryRootThirdExDto {
    @XmlElement(name ="category")
    private List<CategoryThirdExDto> categories;

    public CategoryRootThirdExDto() {
    }

    public List<CategoryThirdExDto> getCategories() {
        return categories;
    }

    public void setCategories(List<CategoryThirdExDto> categories) {
        this.categories = categories;
    }
}

