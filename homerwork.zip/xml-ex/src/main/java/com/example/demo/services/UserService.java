package com.example.demo.services;



import com.example.demo.dtos.fourthEx.UserFourthExDto;
import com.example.demo.dtos.secondEx.UserSecondExDto;
import com.example.demo.dtos.seeds.UserSeedDto;
import com.example.demo.entities.User;

import java.io.IOException;
import java.util.List;

public interface UserService {
    void seedUsers(List<UserSeedDto> userSeedDto) throws IOException;
    User getById(long id);
    int getAllCount();
    List<UserSecondExDto> findAllSecondExercise();
    List<UserFourthExDto> findAllWithSoldProductsFourthExercise();
}
