package com.example.demo.dtos.fourthEx;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserRootFourthExDto {
    @XmlElement(name = "user")
    private List<UserFourthExDto> users;

    @XmlAttribute(name = "count")
    private int count;

    public UserRootFourthExDto() {
    }

    public List<UserFourthExDto> getUsers() {
        return users;
    }

    public void setUsers(List<UserFourthExDto> users) {
        this.users = users;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
