package com.example.demo.services.impl;

import com.example.demo.dtos.fourthEx.ProductFourthExDto;
import com.example.demo.dtos.fourthEx.SoldProductRootFourthDto;
import com.example.demo.dtos.fourthEx.UserFourthExDto;
import com.example.demo.dtos.secondEx.ProductRootSecondExDto;
import com.example.demo.dtos.secondEx.ProductSecondExDto;
import com.example.demo.dtos.secondEx.UserSecondExDto;
import com.example.demo.dtos.seeds.UserSeedDto;
import com.example.demo.entities.Product;
import com.example.demo.entities.User;
import com.example.demo.repositories.UserRepository;
import com.example.demo.services.UserService;
import com.example.demo.utils.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, ValidationUtil validationUtil) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }

    @Override
    public void seedUsers(List<UserSeedDto> userSeedDtos) throws IOException {
        if (this.userRepository.count() != 0) {
            return;
        }

        userSeedDtos
                .forEach(userSeedDto -> {
                    if (this.validationUtil.isValid(userSeedDto)) {
                        User user = this.modelMapper.map(userSeedDto, User.class);
                        this.userRepository.saveAndFlush(user);
                    } else {
                        this.validationUtil.violations(userSeedDto)
                                .stream()
                                .map(ConstraintViolation::getMessage)
                                .forEach(System.out::println);
                    }
                });
    }

    @Override
    public User getById(long id) {
        return this.userRepository.findById(id);
    }

    @Override
    public int getAllCount() {
        return this.userRepository.findAll().size();
    }

    @Override
    public List<UserSecondExDto> findAllSecondExercise() {
        List<User> users = this.userRepository.findAllWithSoldItems();
        List<UserSecondExDto> usersSecondExDtoList = new ArrayList<>();

        for (User user : users) {
            List<ProductSecondExDto> productSecondExDtos = user.getSold()
                    .stream()
                    .filter(product -> product.getBuyer() != null)
                    .map(product -> this.modelMapper.map(product, ProductSecondExDto.class))
                    .collect(Collectors.toList());

            ProductRootSecondExDto productRootSecondExDto = new ProductRootSecondExDto();
            productRootSecondExDto.setProducts(productSecondExDtos);

            UserSecondExDto userSecondExDto = new UserSecondExDto();
            userSecondExDto.setFirstName(user.getFirstName());
            userSecondExDto.setLastName(user.getLastName());
            userSecondExDto.setSoldProducts(productRootSecondExDto);

            usersSecondExDtoList.add(userSecondExDto);
        }

        return usersSecondExDtoList;
    }

    @Override
    public List<UserFourthExDto> findAllWithSoldProductsFourthExercise() {
        List<User> users = this.userRepository.findAllWithSoldItemsExFour();
        List<UserFourthExDto> userFourthExDtoList = new ArrayList<>();

        for (User user : users) {
            List<ProductFourthExDto> productFourthExDtoSet = new ArrayList<>();
            for (Product product : user.getSold()) {
                ProductFourthExDto productFourthExDto = this.modelMapper.map(product, ProductFourthExDto.class);
                productFourthExDtoSet.add(productFourthExDto);
            }

            SoldProductRootFourthDto soldProductRootFourthDto = new SoldProductRootFourthDto();
            soldProductRootFourthDto.setSoldProductsDtos(productFourthExDtoSet);
            soldProductRootFourthDto.setCount(productFourthExDtoSet.size());

            UserFourthExDto userFourthExDto = new UserFourthExDto();
            userFourthExDto.setFirstName(user.getFirstName());
            userFourthExDto.setLastName(user.getLastName());
            userFourthExDto.setAge(user.getAge());
            userFourthExDto.setSoldProducts(soldProductRootFourthDto);

            userFourthExDtoList.add(userFourthExDto);
        }

        return userFourthExDtoList;
    }

}
