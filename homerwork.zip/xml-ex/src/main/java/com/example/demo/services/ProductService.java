package com.example.demo.services;

import com.example.demo.dtos.seeds.ProductSeedDto;
import com.example.demo.entities.Product;

import java.math.BigDecimal;
import java.util.List;

public interface ProductService {
    void seedProducts(List<ProductSeedDto> products);
    List<Product> getAllBetween(BigDecimal lower, BigDecimal higher);
}
