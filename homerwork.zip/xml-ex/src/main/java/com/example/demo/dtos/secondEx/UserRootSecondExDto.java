package com.example.demo.dtos.secondEx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserRootSecondExDto {
    @XmlElement(name = "user")
    private List<UserSecondExDto> users;

    public UserRootSecondExDto() {
    }

    public List<UserSecondExDto> getUsers() {
        return users;
    }

    public void setUsers(List<UserSecondExDto> users) {
        this.users = users;
    }
}
