package com.example.demo.dtos.fourthEx;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "sold-products")
@XmlAccessorType(XmlAccessType.FIELD)
public class SoldProductRootFourthDto {
    @XmlElement(name = "product")
    private List<ProductFourthExDto> soldProductsDtos;
    @XmlAttribute
    private int count;

    public SoldProductRootFourthDto() {
    }

    public List<ProductFourthExDto> getSoldProductsDtos() {
        return soldProductsDtos;
    }

    public void setSoldProductsDtos(List<ProductFourthExDto> soldProductsDtos) {
        this.soldProductsDtos = soldProductsDtos;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
