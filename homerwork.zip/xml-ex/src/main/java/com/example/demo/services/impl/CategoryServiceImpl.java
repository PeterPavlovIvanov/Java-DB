package com.example.demo.services.impl;

import com.example.demo.dtos.seeds.CategorySeedDto;
import com.example.demo.dtos.thirdEx.CategoryThirdExDto;
import com.example.demo.entities.Category;
import com.example.demo.entities.Product;
import com.example.demo.repositories.CategoryRepository;
import com.example.demo.services.CategoryService;
import com.example.demo.utils.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;

    public CategoryServiceImpl(CategoryRepository categoryRepository, ModelMapper modelMapper, ValidationUtil validationUtil) {
        this.categoryRepository = categoryRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }

    @Override
    public void seedCategories(List<CategorySeedDto> categorySeedDtos) {
        if (this.categoryRepository.count() != 0) {
            return;
        }
        categorySeedDtos
                .forEach(categorySeedDto -> {
                    if (this.validationUtil.isValid(categorySeedDto)) {
                        Category category = this.modelMapper.map(categorySeedDto, Category.class);
                        this.categoryRepository.saveAndFlush(category);
                    } else {
                        this.validationUtil.violations(categorySeedDto)
                                .stream()
                                .map(ConstraintViolation::getMessage)
                                .forEach(System.out::println);
                    }
                });
    }

    @Override
    public Category getById(long id) {
        return this.categoryRepository.findById(id);
    }

    @Override
    public List<CategoryThirdExDto> getAllCategoriesThirdEx() {
        List<Category> categories = this.categoryRepository.findAllOrderByProductsSize();
        List<CategoryThirdExDto> categoryThirdExDtoList = new ArrayList<>();

        for (Category category : categories) {
            if(category.getProducts() == null || category.getProducts().size() == 0){
                continue;
            }
            CategoryThirdExDto categoryThirdExDto = new CategoryThirdExDto();

            categoryThirdExDto.setCategory(category.getName());
            categoryThirdExDto.setProductsCount(category.getProducts().size());

            BigDecimal total = new BigDecimal(0);
            BigDecimal count = new BigDecimal(0);
            for (Product product : category.getProducts()) {
                total = total.add(product.getPrice());
                count = count.add(new BigDecimal(1));
            }

            categoryThirdExDto.setTotalRevenue(total);
            categoryThirdExDto.setAveragePrice(total.divide(count, 2, RoundingMode.HALF_UP));

            categoryThirdExDtoList.add(categoryThirdExDto);
        }

        return categoryThirdExDtoList;
    }
}
