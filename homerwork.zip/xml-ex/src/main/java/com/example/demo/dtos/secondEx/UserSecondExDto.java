package com.example.demo.dtos.secondEx;

import javax.xml.bind.annotation.*;
import java.util.Set;

@XmlRootElement(name = "user")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserSecondExDto {

    @XmlAttribute(name = "first-name")
    private String firstName;

    @XmlAttribute(name = "last-name")
    private String lastName;

    @XmlElement(name = "sold-products")
    private ProductRootSecondExDto soldProducts;

    public UserSecondExDto() {
    }

    public ProductRootSecondExDto getSoldProducts() {
        return soldProducts;
    }

    public void setSoldProducts(ProductRootSecondExDto soldProducts) { this.soldProducts = soldProducts; }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
