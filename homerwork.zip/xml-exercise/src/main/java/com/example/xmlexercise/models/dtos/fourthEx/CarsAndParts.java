package com.example.xmlexercise.models.dtos.fourthEx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "cars")
@XmlAccessorType(XmlAccessType.FIELD)
public class CarsAndParts {
    @XmlElement(name = "car")
    private List<CarFourthDto> cars;

    public CarsAndParts() {
    }

    public List<CarFourthDto> getCars() {
        return cars;
    }

    public void setCars(List<CarFourthDto> cars) {
        this.cars = cars;
    }
}
