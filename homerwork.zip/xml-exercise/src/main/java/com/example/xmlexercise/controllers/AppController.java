package com.example.xmlexercise.controllers;

import com.example.xmlexercise.constants.GlobalConstants;
import com.example.xmlexercise.models.dtos.fifthEx.CustomerRootFifthDto;
import com.example.xmlexercise.models.dtos.fourthEx.CarFourthDto;
import com.example.xmlexercise.models.dtos.fourthEx.CarsAndParts;
import com.example.xmlexercise.models.dtos.fourthEx.PartFourthDto;
import com.example.xmlexercise.models.dtos.fourthEx.PartRootFourthDto;
import com.example.xmlexercise.models.dtos.secondEx.CarRootSecondDto;
import com.example.xmlexercise.models.dtos.secondEx.CarSecondDto;
import com.example.xmlexercise.models.dtos.seed.*;
import com.example.xmlexercise.models.dtos.sixthEx.ResultRoodDto;
import com.example.xmlexercise.models.dtos.thirdEx.SupplierRootThirdDto;
import com.example.xmlexercise.models.dtos.thirdEx.SupplierThirdDto;
import com.example.xmlexercise.models.entities.Car;
import com.example.xmlexercise.models.entities.Part;
import com.example.xmlexercise.models.entities.Supplier;
import com.example.xmlexercise.services.*;
import com.example.xmlexercise.utils.XmlParser;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static com.example.xmlexercise.constants.GlobalConstants.*;


@Component
public class AppController implements CommandLineRunner {

    private final XmlParser xmlParser;
    private final SupplierService supplierService;
    private final PartService partService;
    private final CarService carService;
    private final CustomerService customerService;
    private final SaleService saleService;
    private final ModelMapper modelMapper;

    @Autowired
    public AppController(XmlParser xmlParser, SupplierService supplierService, PartService partService, CarService carService, CustomerService customerService, SaleService saleService, ModelMapper modelMapper) {
        this.xmlParser = xmlParser;
        this.supplierService = supplierService;
        this.partService = partService;
        this.carService = carService;
        this.customerService = customerService;
        this.saleService = saleService;
        this.modelMapper = modelMapper;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("0   -> seed data");
        System.out.println("1-6 -> queries 1-6");
        System.out.println("7   -> exit");
        int menu = Integer.parseInt(scanner.nextLine());
        while (true) {
            switch (menu) {
                case 0:
                    this.seedSuppliers();
                    this.seedParts();
                    this.seedCars();
                    this.seedCustomers();
                    this.seedSales();
                    break;
                case 1:
                    this.exercise1();
                    break;
                case 2:
                    this.exercise2();
                    break;
                case 3:
                    this.exercise3();
                    break;
                case 4:
                    this.exercise4();
                    break;
                case 5:
                    this.exercise5();
                    break;
                case 6:
                    this.exercise6();
                    break;
                case 7:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Try again with [0-7]");
                    break;
            }
            System.out.println("0   -> seed data\r\n1-6 -> queries 1-6\r\n7   -> exit");
            menu = Integer.parseInt(scanner.nextLine());
        }
    }

    private void exercise1() throws JAXBException {
        CustomerViewRootDto customerViewRootDto =
                this.customerService.getAllOrderedCustomers();

        this.xmlParser
                .marshalToFile(EX_1_FILE_PATH, customerViewRootDto);
    }

    private void exercise2() throws JAXBException {
        List<Car> toyotas = this.carService.findAllByMake("Toyota");
        List<CarSecondDto> carSecondDtos = new ArrayList<>();

        for (Car car : toyotas) {
            CarSecondDto carSecondDto = this.modelMapper.map(car, CarSecondDto.class);
            carSecondDtos.add(carSecondDto);
        }

        CarRootSecondDto carRootSecondDto = new CarRootSecondDto();
        carRootSecondDto.setCars(carSecondDtos);

        this.xmlParser
                .marshalToFile(EX_2_FILE_PATH, carRootSecondDto);
    }

    private void exercise3() throws JAXBException {
        List<Supplier> suppliers = this.supplierService.getThirdExercise();
        List<SupplierThirdDto> supplierThirdDtoList = new ArrayList<>();

        for (Supplier supplier : suppliers) {
            SupplierThirdDto supplierThirdDto =
                    new SupplierThirdDto(
                            supplier.getId(),
                            supplier.getName(),
                            this.partService.findAllBySupplier(supplier).size()
                    );

            supplierThirdDtoList.add(supplierThirdDto);
        }

        SupplierRootThirdDto supplierRootThirdDto = new SupplierRootThirdDto();
        supplierRootThirdDto.setSuppliers(supplierThirdDtoList);

        this.xmlParser.marshalToFile(EX_3_FILE_PATH, supplierRootThirdDto);
    }

    private void exercise4() throws JAXBException {
        List<Car> allCars = this.carService.getAll();

        CarsAndParts carsAndParts = new CarsAndParts();
        carsAndParts.setCars(new ArrayList<>());

        for (Car car : allCars) {
            PartRootFourthDto partRootFourthDto = new PartRootFourthDto();
            List<PartFourthDto> partFourthDtoList = new ArrayList<>();

            for (Part part : car.getParts()) {
                PartFourthDto partFourthDto = this.modelMapper.map(part, PartFourthDto.class);
                partFourthDtoList.add(partFourthDto);
            }
            partRootFourthDto.setParts(partFourthDtoList);

            CarFourthDto carFourthDto = this.modelMapper.map(car, CarFourthDto.class);
            carFourthDto.setParts(partRootFourthDto);

            carsAndParts.getCars().add(carFourthDto);
        }

        this.xmlParser.marshalToFile(EX_4_FILE_PATH, carsAndParts);
    }

    private void exercise5() throws JAXBException {
        CustomerRootFifthDto customerRootFifthDto = new CustomerRootFifthDto();
        customerRootFifthDto.setCustomers(this.saleService.getExerciseFive());

        this.xmlParser.marshalToFile(EX_5_FILE_PATH, customerRootFifthDto);
    }

    private void exercise6() throws JAXBException {
        ResultRoodDto resultRoodDto = new ResultRoodDto();
        resultRoodDto.setSales(this.saleService.getExerciseSix());

        this.xmlParser.marshalToFile(EX_6_FILE_PATH, resultRoodDto);
    }

    private void seedSales() {
        this.saleService.seedSales();
    }

    private void seedCustomers() throws JAXBException, FileNotFoundException {
        CustomerSeedRootDto customerSeedRootDto = this.xmlParser
                .unmarshalFromFile(CUSTOMERS_FILE_PATH, CustomerSeedRootDto.class);

        this.customerService.seedCustomers(customerSeedRootDto.getCustomers());
    }

    private void seedCars() throws JAXBException, FileNotFoundException {
        CarSeedRootDto carSeedRootDto = this.xmlParser
                .unmarshalFromFile(CARS_FILE_PATH, CarSeedRootDto.class);


        this.carService.seedCars(carSeedRootDto.getCars());
    }

    private void seedParts() throws JAXBException, FileNotFoundException {
        PartSeedRootDto partSeedRootDto = this.xmlParser
                .unmarshalFromFile(PARTS_FILE_PATH, PartSeedRootDto.class);


        this.partService.seedParts(partSeedRootDto.getParts());
    }

    private void seedSuppliers() throws JAXBException, FileNotFoundException {
        SupplierSeedRootDto supplierSeedRootDto = this.xmlParser
                .unmarshalFromFile(GlobalConstants.SUPPLIERS_FILE_PATH, SupplierSeedRootDto.class);

        this.supplierService.seedSuppliers(supplierSeedRootDto.getSuppliers());
    }
}
