package com.example.xmlexercise.services;


import com.example.xmlexercise.models.dtos.seed.PartSeedDto;
import com.example.xmlexercise.models.entities.Part;
import com.example.xmlexercise.models.entities.Supplier;

import java.util.List;
import java.util.Set;

public interface PartService {
    void seedParts(List<PartSeedDto> partSeedDtos);

    Set<Part> getRandomParts();

    List<Part> findAllBySupplier(Supplier supplier);

}
