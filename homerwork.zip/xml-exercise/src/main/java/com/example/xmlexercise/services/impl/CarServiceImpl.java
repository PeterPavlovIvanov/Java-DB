package com.example.xmlexercise.services.impl;

import com.example.xmlexercise.models.dtos.seed.CarSeedDto;
import com.example.xmlexercise.models.entities.Car;
import com.example.xmlexercise.repositories.CarRepository;
import com.example.xmlexercise.services.CarService;
import com.example.xmlexercise.services.PartService;
import com.example.xmlexercise.utils.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import java.util.List;
import java.util.Random;

@Service
@Transactional
public class CarServiceImpl implements CarService {

    private final CarRepository carRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final PartService partService;
    private final Random random;


    @Autowired
    public CarServiceImpl(CarRepository carRepository, ModelMapper modelMapper, ValidationUtil validationUtil, PartService partService, Random random) {
        this.carRepository = carRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.partService = partService;
        this.random = random;
    }


    @Override
    public void seedCars(List<CarSeedDto> carSeedDtos) {
        carSeedDtos
                .forEach(carSeedDto -> {
                    if(this.validationUtil.isValid(carSeedDto)){
                        if(this.carRepository
                        .findByMakeAndModelAndTravelledDistance(carSeedDto.getMake(),
                                carSeedDto.getModel(), carSeedDto.getTravelledDistance()) == null){

                            Car car = this.modelMapper.map(carSeedDto, Car.class);
                            car.setParts(this.partService.getRandomParts());


                            this.carRepository.saveAndFlush(car);
                        }else {
                            System.out.println("Already in DB");
                        }

                    }else {
                        this.validationUtil
                                .violations(carSeedDto)
                                .stream()
                                .map(ConstraintViolation::getMessage)
                                .forEach(System.out::println);
                    }
                });
    }

    @Override
    public Car getRandomCar() {
        long randomId = this.random
                .nextInt((int) this.carRepository.count()) + 1;

        return this.carRepository.getOne(randomId);
    }

    @Override
    public List<Car> findAllByMake(String make) {
        return this.carRepository.findAllByMakeOrderByModelAscTravelledDistanceDesc(make);
    }

    @Override
    public List<Car> getAll() {
        return this.carRepository.findAll();
    }

}
