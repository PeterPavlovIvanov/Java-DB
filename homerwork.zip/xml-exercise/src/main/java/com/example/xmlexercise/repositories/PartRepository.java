package com.example.xmlexercise.repositories;

import com.example.xmlexercise.models.entities.Part;
import com.example.xmlexercise.models.entities.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface PartRepository extends JpaRepository<Part, Long> {
    Part findByNameAndPrice(String name, BigDecimal price);
    List<Part> findAllBySupplier(Supplier supplier);

}
