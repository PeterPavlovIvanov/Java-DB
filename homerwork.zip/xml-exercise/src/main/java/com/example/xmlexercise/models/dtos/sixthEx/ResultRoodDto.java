package com.example.xmlexercise.models.dtos.sixthEx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "sales")
@XmlAccessorType(XmlAccessType.FIELD)
public class ResultRoodDto {
    @XmlElement(name = "sale")
    private List<ResultDto> sales;

    public ResultRoodDto() {
    }

    public List<ResultDto> getSales() {
        return sales;
    }

    public void setSales(List<ResultDto> sales) {
        this.sales = sales;
    }
}
