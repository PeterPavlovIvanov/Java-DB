package com.example.xmlexercise.services;

import com.example.xmlexercise.models.dtos.fifthEx.CustomerDto;
import com.example.xmlexercise.models.dtos.sixthEx.ResultDto;

import java.util.List;

public interface SaleService {
    void  seedSales();
    List<ResultDto> getExerciseSix();
    List<CustomerDto> getExerciseFive();
}
