package com.example.xmlexercise.services;


import com.example.xmlexercise.models.dtos.seed.CarSeedDto;
import com.example.xmlexercise.models.entities.Car;

import java.util.List;

public interface CarService {
    void seedCars(List<CarSeedDto> carSeedDtos);

    Car getRandomCar();

    List<Car> findAllByMake(String make);

    List<Car> getAll();
}
