package com.example.xmlexercise.services;


import com.example.xmlexercise.models.dtos.seed.SupplierSeedDto;
import com.example.xmlexercise.models.entities.Supplier;

import java.util.List;

public interface SupplierService {
    void seedSuppliers(List<SupplierSeedDto> supplierSeedDtos);

    Supplier getRandomSupplier();

    List<Supplier> getThirdExercise();

}
