package com.example.xmlexercise.models.dtos.secondEx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "cars")
@XmlAccessorType(XmlAccessType.FIELD)
public class CarRootSecondDto {

    @XmlElement(name = "car")
    private List<CarSecondDto> cars;

    public CarRootSecondDto() {

    }

    public List<CarSecondDto> getCars() {
        return cars;
    }

    public void setCars(List<CarSecondDto> cars) {
        this.cars = cars;
    }
}
