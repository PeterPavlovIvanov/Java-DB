package com.example.xmlexercise.repositories;

import com.example.xmlexercise.models.entities.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SupplierRepository extends JpaRepository<Supplier, Long> {
    Supplier findByName(String name);

    List<Supplier> findAllByImporterFalse();

}
