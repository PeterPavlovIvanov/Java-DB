package com.example.xmlexercise.services;


import com.example.xmlexercise.models.dtos.seed.CustomerSeedDto;
import com.example.xmlexercise.models.dtos.seed.CustomerViewRootDto;
import com.example.xmlexercise.models.entities.Customer;

import java.util.List;

public interface CustomerService {
    void seedCustomers(List<CustomerSeedDto> customerSeedDtos);

    Customer getRandomCustomer();

    CustomerViewRootDto getAllOrderedCustomers();

    List<Customer> getAll();

}
