package hiberspring.service.impl;

import hiberspring.common.Constants;
import hiberspring.domain.dtos.ProductSeedDto;
import hiberspring.domain.dtos.ProductSeedRootDto;
import hiberspring.domain.entities.Product;
import hiberspring.repository.BranchRepository;
import hiberspring.repository.ProductRepository;
import hiberspring.service.ProductService;
import hiberspring.util.ValidationUtil;
import hiberspring.util.XmlParser;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;
    private final BranchRepository branchRepository;

    public ProductServiceImpl(ProductRepository productRepository, ModelMapper modelMapper, XmlParser xmlParser, ValidationUtil validationUtil, BranchRepository branchRepository) {
        this.productRepository = productRepository;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
        this.branchRepository = branchRepository;
    }

    @Override
    public Boolean productsAreImported() {
        return productRepository.count() > 0;
    }

    @Override
    public String readProductsXmlFile() throws IOException {
        return Files.readString(Path.of(Constants.PATH_TO_FILES + "products.xml"));
    }

    @Override
    public String importProducts() throws JAXBException, FileNotFoundException {
        StringBuilder rs = new StringBuilder();
        ProductSeedRootDto productSeedRootDto = this.xmlParser.parseXml(ProductSeedRootDto.class, Constants.PATH_TO_FILES + "products.xml");

        for (ProductSeedDto productSeedDto : productSeedRootDto.getProducts()) {

            if (this.validationUtil.isValid(productSeedDto)) {

                if (this.productRepository.findByName(productSeedDto.getName()) == null) {

                    Product product = this.modelMapper.map(productSeedDto, Product.class);
                    product.setBranch(this.branchRepository.findByName(productSeedDto.getBranchName()));
                    this.productRepository.saveAndFlush(product);
                    rs.append(String.format(Constants.SUCCESSFUL_IMPORT_MESSAGE, "Product", productSeedDto.getName()));

                } else {
                    rs.append("Already in db");
                }

            } else {
                rs.append(Constants.INCORRECT_DATA_MESSAGE);
            }
            rs.append(System.lineSeparator());
        }

        return rs.toString();
    }
}
