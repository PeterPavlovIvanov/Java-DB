package hiberspring.service.impl;

import com.google.gson.Gson;
import hiberspring.common.Constants;
import hiberspring.domain.dtos.EmployeeCardSeedDto;
import hiberspring.domain.entities.Employee;
import hiberspring.domain.entities.EmployeeCard;
import hiberspring.repository.EmployeeCardRepository;
import hiberspring.service.EmployeeCardService;
import hiberspring.util.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class EmployeeCardServiceImpl implements EmployeeCardService {

    private final EmployeeCardRepository employeeCardRepository;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;


    public EmployeeCardServiceImpl(EmployeeCardRepository employeeCardRepository, Gson gson, ValidationUtil validationUtil, ModelMapper modelMapper) {
        this.employeeCardRepository = employeeCardRepository;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public Boolean employeeCardsAreImported() {
        return this.employeeCardRepository.count() > 0;
    }

    @Override
    public String readEmployeeCardsJsonFile() throws IOException {
        return Files.readString(Path.of(Constants.PATH_TO_FILES + "employee-cards.json"));
    }

    @Override
    public String importEmployeeCards(String employeeCardsFileContent) throws FileNotFoundException {
        StringBuilder rs = new StringBuilder();

        EmployeeCardSeedDto[] employeeCardSeedDtos =
                this.gson.fromJson(
                        new FileReader(Constants.PATH_TO_FILES + "employee-cards.json"),
                        EmployeeCardSeedDto[].class);

        for (EmployeeCardSeedDto employeeCardSeedDto : employeeCardSeedDtos) {

            if (this.validationUtil.isValid(employeeCardSeedDto)) {

                if (this.employeeCardRepository.findByNumber(employeeCardSeedDto.getNumber()) == null) {

                    EmployeeCard employeeCard = this.modelMapper.map(employeeCardSeedDto, EmployeeCard.class);
                    this.employeeCardRepository.saveAndFlush(employeeCard);
                    rs.append(String.format(Constants.SUCCESSFUL_IMPORT_MESSAGE, "Employee Card", employeeCardSeedDto.getNumber()));

                } else {
                    rs.append("Already in db");
                }

            } else {
                rs.append(Constants.INCORRECT_DATA_MESSAGE);
            }
            rs.append(System.lineSeparator());
        }

        return rs.toString();
    }
}
