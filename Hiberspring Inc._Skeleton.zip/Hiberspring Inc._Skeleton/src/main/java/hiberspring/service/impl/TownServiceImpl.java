package hiberspring.service.impl;

import com.google.gson.Gson;
import hiberspring.common.Constants;
import hiberspring.domain.dtos.TownSeedDto;
import hiberspring.domain.entities.Town;
import hiberspring.repository.TownRepository;
import hiberspring.service.TownService;
import hiberspring.util.FileUtil;
import hiberspring.util.ValidationUtil;
import hiberspring.util.XmlParser;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class TownServiceImpl implements TownService {

    private final TownRepository townRepository;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;
    private final Gson gson;

    public TownServiceImpl(TownRepository townRepository, ModelMapper modelMapper, XmlParser xmlParser, ValidationUtil validationUtil, Gson gson) {
        this.townRepository = townRepository;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
        this.gson = gson;
    }

    @Override
    public Boolean townsAreImported() {
        return this.townRepository.count() > 0;
    }

    @Override
    public String readTownsJsonFile() throws IOException {
        return Files.readString(Path.of(Constants.PATH_TO_FILES + "towns.json"));
    }

    @Override
    public String importTowns(String townsFileContent) throws IOException {
        StringBuilder result = new StringBuilder();

        TownSeedDto[] townSeedDtos =
                this.gson.fromJson(
                        new FileReader(Constants.PATH_TO_FILES + "towns.json"), TownSeedDto[].class
                );

        for (TownSeedDto townSeedDto : townSeedDtos) {
            if (this.validationUtil.isValid(townSeedDto)) {

                if(townSeedDto.getName() == null){
                    result.append(Constants.INCORRECT_DATA_MESSAGE).append(System.lineSeparator());
                    continue;
                }

                if (this.townRepository.findByName(townSeedDto.getName()) == null) {

                    Town town = this.modelMapper.map(townSeedDto, Town.class);
                    this.townRepository.saveAndFlush(town);
                    result.append(String.format(Constants.SUCCESSFUL_IMPORT_MESSAGE, "town", townSeedDto.getName()));

                } else {
                    result.append("Already in db");
                }

            } else {
                result.append(Constants.INCORRECT_DATA_MESSAGE);
            }
            result.append(System.lineSeparator());
        }

        return result.toString();
    }

    @Override
    public Town getByName(String name) {
        return this.townRepository.findByName(name);
    }
}
