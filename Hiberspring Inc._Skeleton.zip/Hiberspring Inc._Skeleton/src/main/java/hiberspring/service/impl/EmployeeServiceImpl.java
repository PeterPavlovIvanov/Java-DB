package hiberspring.service.impl;

import hiberspring.common.Constants;
import hiberspring.domain.dtos.EmployeeSeedDto;
import hiberspring.domain.dtos.EmployeeSeedRootDto;
import hiberspring.domain.entities.Branch;
import hiberspring.domain.entities.Employee;
import hiberspring.repository.BranchRepository;
import hiberspring.repository.EmployeeCardRepository;
import hiberspring.repository.EmployeeRepository;
import hiberspring.repository.ProductRepository;
import hiberspring.service.EmployeeService;
import hiberspring.util.ValidationUtil;
import hiberspring.util.XmlParser;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;
    private final BranchRepository branchRepository;
    private final EmployeeCardRepository employeeCardRepository;
    private final ProductRepository productRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository, XmlParser xmlParser, ValidationUtil validationUtil, ModelMapper modelMapper, BranchRepository branchRepository, EmployeeCardRepository employeeCardRepository, ProductRepository productRepository) {
        this.employeeRepository = employeeRepository;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.branchRepository = branchRepository;
        this.employeeCardRepository = employeeCardRepository;
        this.productRepository = productRepository;
    }

    @Override
    public Boolean employeesAreImported() {
        return this.employeeRepository.count() > 0;
    }

    @Override
    public String readEmployeesXmlFile() throws IOException {
        return Files.readString(Path.of(Constants.PATH_TO_FILES + "employees.xml"));
    }

    @Override
    public String importEmployees() throws JAXBException, FileNotFoundException {
        StringBuilder rs = new StringBuilder();
        EmployeeSeedRootDto employeeSeedRootDto =
                this.xmlParser.parseXml(EmployeeSeedRootDto.class, Constants.PATH_TO_FILES + "employees.xml");

        for (EmployeeSeedDto employeeSeedDto : employeeSeedRootDto.getEmployees()) {

            if (this.validationUtil.isValid(employeeSeedDto)) {

                if (this.employeeRepository.findByFirstNameAndLastName(employeeSeedDto.getFirstName(), employeeSeedDto.getLastName()) == null) {

                    Employee employee = this.modelMapper.map(employeeSeedDto, Employee.class);
                    employee.setBranch(this.branchRepository.findByName(employeeSeedDto.getBranchName()));
                    employee.setEmployeeCard(this.employeeCardRepository.findByNumber(employeeSeedDto.getCardNumber()));
                    this.employeeRepository.saveAndFlush(employee);
                    rs.append(String.format(Constants.SUCCESSFUL_IMPORT_MESSAGE,
                            "Employee", employeeSeedDto.getFirstName() + " " + employeeSeedDto.getLastName()));

                } else {
                    rs.append("Already in db");
                }

            } else {
                rs.append(Constants.INCORRECT_DATA_MESSAGE);
            }

            rs.append(System.lineSeparator());
        }

        return rs.toString();
    }

    @Override
    public String exportProductiveEmployees() {
        List<Employee> employees = this.employeeRepository.findAllOrdered();
        employees = employees.stream().filter(employee -> {
            Branch branch = employee.getBranch();
            int size = this.productRepository.findAllByBranch(branch).size();
            return size > 0;
        }).collect(Collectors.toList());

        StringBuilder result = new StringBuilder();
        for(Employee employee: employees){
            result.append(String.format("Name: %s %s\r\n" +
                            "Position: %s\r\n" +
                            "Card Number: %s\r\n" +
                            "-------------------------\r\n"
                    , employee.getFirstName(), employee.getLastName(),
                    employee.getPosition(), employee.getEmployeeCard().getNumber()));
        }

        return result.toString();
    }
}
