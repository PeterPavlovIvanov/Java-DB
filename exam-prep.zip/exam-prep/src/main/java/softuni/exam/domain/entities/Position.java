package softuni.exam.domain.entities;

public enum Position {
    GK,CD,RB,LB,CM,DM,CDM,LM,RM,ST,CF,RW,LW
}
