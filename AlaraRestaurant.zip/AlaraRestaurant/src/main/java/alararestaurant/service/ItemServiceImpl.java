package alararestaurant.service;

import alararestaurant.domain.dtos.CategorySeedDto;
import alararestaurant.domain.dtos.ItemSeedDto;
import alararestaurant.domain.entities.Category;
import alararestaurant.domain.entities.Item;
import alararestaurant.repository.CategoryRepository;
import alararestaurant.repository.ItemRepository;
import alararestaurant.util.ValidationUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class ItemServiceImpl implements ItemService {

    private final ItemRepository itemRepository;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;
    private final CategoryRepository categoryRepository;

    public ItemServiceImpl(ItemRepository itemRepository, Gson gson, ValidationUtil validationUtil, ModelMapper modelMapper, CategoryRepository categoryRepository) {
        this.itemRepository = itemRepository;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.categoryRepository = categoryRepository;
    }

    @Override
    public Boolean itemsAreImported() {
        return this.itemRepository.count() > 0;
    }

    @Override
    public String readItemsJsonFile() throws IOException {
        return Files.readString(Path.of("src/main/resources/files/items.json"));
    }

    @Override
    public String importItems(String items) throws FileNotFoundException {
        StringBuilder sb = new StringBuilder();

        ItemSeedDto[] itemSeedDtoList = this.gson.fromJson(new FileReader("src/main/resources/files/items.json"), ItemSeedDto[].class);

        for (ItemSeedDto itemSeedDto : itemSeedDtoList) {

            if (this.validationUtil.isValid(itemSeedDto) && this.itemRepository.findByName(itemSeedDto.getName()) == null) {
                CategorySeedDto categorySeedDto = new CategorySeedDto(itemSeedDto.getCategory());

                if (this.validationUtil.isValid(categorySeedDto)) {
                    Item item = this.modelMapper.map(itemSeedDto, Item.class);

                    if (this.categoryRepository.findByName(categorySeedDto.getName()).size() > 0) {
                        item.setCategory(this.categoryRepository.findByName(categorySeedDto.getName()).get(0));
                    } else {
                        Category category = this.modelMapper.map(categorySeedDto, Category.class);
                        item.setCategory(category);
                    }

                    this.itemRepository.save(item);
                    sb.append(String.format("Record %s successfully imported.", item.getName())).append(System.lineSeparator());
                } else {
                    sb.append("Invalid data format.").append(System.lineSeparator());
                }

            } else {
                sb.append("Invalid data format.").append(System.lineSeparator());
            }

        }

        return sb.toString();
    }
}
