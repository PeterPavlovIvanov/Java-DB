package alararestaurant.service;

import alararestaurant.domain.entities.Category;
import alararestaurant.domain.entities.Item;
import alararestaurant.repository.CategoryRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;

    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public String exportCategoriesByCountOfItems() {
        List<Category> categories = this.categoryRepository.firstExportEx();

        StringBuilder result = new StringBuilder();
        for (Category category : categories) {
            result.append("Category: ").append(category.getName()).append("\r\n");

            for (Item item : category.getItems()) {
                result.append("--- Item Name: ").append(item.getName()).append("\r\n");
                result.append(String.format("--- Item Price: %.2f\r\n", item.getPrice()));
                result.append("\r\n");
            }
            result.append("\r\n");
        }

        return result.toString();
    }
}
