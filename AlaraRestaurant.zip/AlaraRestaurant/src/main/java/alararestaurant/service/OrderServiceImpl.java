package alararestaurant.service;

import alararestaurant.domain.dtos.xmlDtos.ItemSeedDto2;
import alararestaurant.domain.dtos.xmlDtos.OrderRootSeedDto;
import alararestaurant.domain.dtos.xmlDtos.OrderSeedDto;
import alararestaurant.domain.entities.*;
import alararestaurant.repository.*;
import alararestaurant.util.ValidationUtil;
import alararestaurant.util.XmlParser;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final XmlParser xmlParser;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final EmployeeRepository employeeRepository;
    private final ItemRepository itemRepository;
    private final OrderItemRepository orderItemRepository;
    private final PositionRepository positionRepository;

    public OrderServiceImpl(OrderRepository orderRepository, XmlParser xmlParser, ModelMapper modelMapper, ValidationUtil validationUtil, EmployeeRepository employeeRepository, ItemRepository itemRepository, OrderItemRepository orderItemRepository, PositionRepository positionRepository) {
        this.orderRepository = orderRepository;
        this.xmlParser = xmlParser;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.employeeRepository = employeeRepository;
        this.itemRepository = itemRepository;
        this.orderItemRepository = orderItemRepository;
        this.positionRepository = positionRepository;
    }

    @Override
    public Boolean ordersAreImported() {
        return this.orderRepository.count() > 0;
    }

    @Override
    public String readOrdersXmlFile() throws IOException {
        return Files.readString(Path.of("src/main/resources/files/orders.xml"));
    }

    @Override
    public String importOrders() throws JAXBException, FileNotFoundException, ParseException {
        StringBuilder sb = new StringBuilder();
        OrderRootSeedDto orderRootSeedDto =
                this.xmlParser.unmarshalFromFile("src/main/resources/files/orders.xml", OrderRootSeedDto.class);

        for (OrderSeedDto orderSeedDto : orderRootSeedDto.getOrderSeedDto()) {

            if (this.validationUtil.isValid(orderRootSeedDto)) {

                if (this.employeeRepository.findByName(orderSeedDto.getEmployeeName()) != null) {
                    Order order = new Order();
                    order.setCustomer(orderSeedDto.getCustomer());
                    order.setEmployee(this.employeeRepository.findByName(orderSeedDto.getEmployeeName()));

                    Date date = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse(orderSeedDto.getDateTime());
                    order.setDateTime(date);

                    if (orderSeedDto.getType().equals("ForHere")) {
                        order.setType(OrderType.ForHere);
                    } else {
                        order.setType(OrderType.ToGo);
                    }

                    List<OrderItem> orderItems = new ArrayList<>();
                    boolean areItemsCorrect = true;
                    for (ItemSeedDto2 itemSeedDto2 : orderSeedDto.getItemRootSeedDto().getItemSeedDto2s()) {
                        if (!this.validationUtil.isValid(itemSeedDto2) ||
                                this.itemRepository.findByName(itemSeedDto2.getName()) == null) {
                            areItemsCorrect = false;
                            break;
                        }
                        Item item = this.itemRepository.findByName(itemSeedDto2.getName());

                        OrderItem orderItem = new OrderItem();
                        orderItem.setItem(item);
                        orderItem.setQuantity(itemSeedDto2.getQuantity());
                        orderItem.setOrder(order);

                        orderItems.add(orderItem);
                    }

                    if (areItemsCorrect) {
                        order.setOrderItems(orderItems);

                        this.orderRepository.saveAndFlush(order);
                        for (OrderItem orderItem : order.getOrderItems()) {
                            this.orderItemRepository.save(orderItem);
                        }
                        sb.append(String.format("Order for %s on %s added",
                                order.getCustomer(), orderSeedDto.getDateTime())).append(System.lineSeparator());

                    } else {
                        sb.append("Invalid data format.").append(System.lineSeparator());
                    }

                } else {
                    sb.append("Invalid data format.").append(System.lineSeparator());
                }

            } else {
                sb.append("Invalid data format.").append(System.lineSeparator());
            }

        }

        return sb.toString();
    }

    @Override
    public String exportOrdersFinishedByTheBurgerFlippers() {
        Position burgerFlipper = this.positionRepository.findByName("Burger Flipper").get(0);
        List<Order> orders = this.orderRepository.findAllByEmployeePositionOrderByEmployeeNameAscIdAsc(burgerFlipper);

        StringBuilder result = new StringBuilder();
        for (Order order : orders) {
            result.append("Name ").append(order.getEmployee().getName()).append("\r\n");
            result.append("Orders:\r\n");
            result.append("  Customer: ").append(order.getCustomer()).append("\r\n");
            result.append("  Items:\r\n");
            for (OrderItem orderItem : order.getOrderItems()) {
                result.append("    Name: ").append(orderItem.getItem().getName()).append("\r\n");
                result.append(String.format("    Price: %.2f\r\n", orderItem.getItem().getPrice()));
                result.append("    Quantity: ").append(orderItem.getQuantity()).append("\r\n");
                result.append("\r\n");
            }
            result.append("\r\n");
        }

        return result.toString();
    }
}
