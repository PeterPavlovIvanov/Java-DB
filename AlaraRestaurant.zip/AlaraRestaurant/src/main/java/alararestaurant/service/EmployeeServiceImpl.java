package alararestaurant.service;

import alararestaurant.domain.dtos.EmployeeSeedDto;
import alararestaurant.domain.dtos.PositionSeedDto;
import alararestaurant.domain.entities.Employee;
import alararestaurant.domain.entities.Position;
import alararestaurant.repository.EmployeeRepository;
import alararestaurant.repository.PositionRepository;
import alararestaurant.util.ValidationUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final Gson gson;
    private final PositionRepository positionRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository, ModelMapper modelMapper, ValidationUtil validationUtil, Gson gson, PositionRepository positionRepository) {
        this.employeeRepository = employeeRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.gson = gson;
        this.positionRepository = positionRepository;
    }

    @Override
    public Boolean employeesAreImported() {
        return this.employeeRepository.count() > 0;
    }

    @Override
    public String readEmployeesJsonFile() throws IOException {
        return Files.readString(Path.of("src/main/resources/files/employees.json"));
    }

    @Override
    public String importEmployees(String employees) throws FileNotFoundException {
        StringBuilder sb = new StringBuilder();

        EmployeeSeedDto[] employeeSeedDtoList =
                this.gson.fromJson(new FileReader("src/main/resources/files/employees.json"),
                        EmployeeSeedDto[].class);

        for (EmployeeSeedDto employeeSeedDto : employeeSeedDtoList) {

            if (this.validationUtil.isValid(employeeSeedDto)) {

                if (!employeeSeedDto.getPosition().equals("") && !(employeeSeedDto.getPosition().length() > 30)) {
                    PositionSeedDto positionSeedDto = new PositionSeedDto(employeeSeedDto.getPosition());
                    Position position = this.modelMapper.map(positionSeedDto, Position.class);

                    if (this.validationUtil.isValid(position)) {
                        Employee employee = this.modelMapper.map(employeeSeedDto, Employee.class);

                        if (this.positionRepository.findByName(employeeSeedDto.getPosition()).size() > 0) {
                            employee.setPosition(this.positionRepository.findByName(employeeSeedDto.getPosition()).get(0));
                        } else {
                            employee.setPosition(position);
                        }

                        this.employeeRepository.saveAndFlush(employee);
                        sb.append(String.format("Record %s successfully imported.", employeeSeedDto.getName()))
                                .append(System.lineSeparator());
                    } else {
                        sb.append("Invalid data format.").append(System.lineSeparator());
                    }

                } else {
                    sb.append("Invalid data format.").append(System.lineSeparator());
                }

            } else {
                sb.append("Invalid data format.").append(System.lineSeparator());
            }

        }

        return sb.toString();
    }
}
