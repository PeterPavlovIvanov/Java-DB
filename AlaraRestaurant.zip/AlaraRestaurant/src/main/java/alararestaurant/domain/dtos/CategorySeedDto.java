package alararestaurant.domain.dtos;

import com.google.gson.annotations.Expose;
import org.hibernate.validator.constraints.Length;
import org.springframework.lang.NonNull;

import javax.validation.constraints.NotNull;

public class CategorySeedDto {
    @Expose
    private String name;

    public CategorySeedDto(String name) {
        this.name = name;
    }

    @NotNull
    @NonNull
    @Length(min = 3, max = 30)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
