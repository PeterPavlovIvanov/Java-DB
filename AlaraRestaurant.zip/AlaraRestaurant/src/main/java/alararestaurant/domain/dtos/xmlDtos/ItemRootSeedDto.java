package alararestaurant.domain.dtos.xmlDtos;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "items")
@XmlAccessorType(XmlAccessType.FIELD)
public class ItemRootSeedDto {
    @XmlElement(name = "item")
    private List<ItemSeedDto2> itemSeedDto2s;

    public ItemRootSeedDto() {
    }

    public List<ItemSeedDto2> getItemSeedDto2s() {
        return itemSeedDto2s;
    }

    public void setItemSeedDto2s(List<ItemSeedDto2> itemSeedDto2s) {
        this.itemSeedDto2s = itemSeedDto2s;
    }
}
