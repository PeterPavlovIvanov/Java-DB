package alararestaurant.domain.dtos;

import com.google.gson.annotations.Expose;

public class PositionSeedDto {
   @Expose
    private String name;

    public PositionSeedDto(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
